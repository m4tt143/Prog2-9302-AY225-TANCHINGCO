import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Prelim Grade Calculator - GUI Version
 * This program computes the required Prelim Exam score a student needs
 * to achieve either a passing grade (75) or excellent grade (100).
 * 
 * Grading Breakdown:
 * - Prelim Grade = (Prelim Exam × 0.30) + (Class Standing × 0.70)
 * - Class Standing = (Attendance × 0.40) + (Lab Work Average × 0.60)
 * - Lab Work Average = (Lab1 + Lab2 + Lab3) / 3
 */
public class PrelimGradeCalculatorGUI extends JFrame {
    
    // Constants for grading weights
    private static final double PRELIM_EXAM_WEIGHT = 0.30;
    private static final double CLASS_STANDING_WEIGHT = 0.70;
    private static final double ATTENDANCE_WEIGHT = 0.40;
    private static final double LAB_WORK_WEIGHT = 0.60;
    private static final double PASSING_GRADE = 75.0;
    private static final double EXCELLENT_GRADE = 100.0;
    private static final int TOTAL_CLASSES = 15;
    
    // GUI Components
    private JTextField attendanceField;
    private JTextField lab1Field;
    private JTextField lab2Field;
    private JTextField lab3Field;
    private JTextArea resultArea;
    private JButton calculateButton;
    private JButton resetButton;
    
    public PrelimGradeCalculatorGUI() {
        setTitle("Prelim Grade Calculator");
        setSize(600, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Create main panel with padding
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Color.WHITE);
        
        // Header
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Input Panel
        JPanel inputPanel = createInputPanel();
        mainPanel.add(inputPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Button Panel
        JPanel buttonPanel = createButtonPanel();
        mainPanel.add(buttonPanel);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Result Panel
        JPanel resultPanel = createResultPanel();
        mainPanel.add(resultPanel);
        
        add(mainPanel);
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(37, 99, 235));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel titleLabel = new JLabel("Prelim Grade Calculator");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Calculate your required Prelim Exam score");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        subtitleLabel.setForeground(Color.WHITE);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        panel.add(titleLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 5)));
        panel.add(subtitleLabel);
        
        return panel;
    }
    
    private JPanel createInputPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2, 10, 15));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(209, 213, 219), 1),
            "Input Information",
            0,
            0,
            new Font("Arial", Font.BOLD, 14),
            new Color(55, 65, 81)
        ));
        panel.setBorder(BorderFactory.createCompoundBorder(
            panel.getBorder(),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        // Attendance
        JLabel attendanceLabel = new JLabel("Number of Attendances (0-15):");
        attendanceLabel.setFont(new Font("Arial", Font.PLAIN, 13));
        attendanceField = new JTextField();
        attendanceField.setFont(new Font("Arial", Font.PLAIN, 13));
        
        // Lab 1
        JLabel lab1Label = new JLabel("Lab Work 1 Grade (0-100):");
        lab1Label.setFont(new Font("Arial", Font.PLAIN, 13));
        lab1Field = new JTextField();
        lab1Field.setFont(new Font("Arial", Font.PLAIN, 13));
        
        // Lab 2
        JLabel lab2Label = new JLabel("Lab Work 2 Grade (0-100):");
        lab2Label.setFont(new Font("Arial", Font.PLAIN, 13));
        lab2Field = new JTextField();
        lab2Field.setFont(new Font("Arial", Font.PLAIN, 13));
        
        // Lab 3
        JLabel lab3Label = new JLabel("Lab Work 3 Grade (0-100):");
        lab3Label.setFont(new Font("Arial", Font.PLAIN, 13));
        lab3Field = new JTextField();
        lab3Field.setFont(new Font("Arial", Font.PLAIN, 13));
        
        panel.add(attendanceLabel);
        panel.add(attendanceField);
        panel.add(lab1Label);
        panel.add(lab1Field);
        panel.add(lab2Label);
        panel.add(lab2Field);
        panel.add(lab3Label);
        panel.add(lab3Field);
        
        return panel;
    }
    
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0));
        panel.setBackground(Color.WHITE);
        
        calculateButton = new JButton("Calculate");
        calculateButton.setFont(new Font("Arial", Font.BOLD, 14));
        calculateButton.setBackground(new Color(37, 99, 235));
        calculateButton.setForeground(Color.WHITE);
        calculateButton.setFocusPainted(false);
        calculateButton.setBorderPainted(false);
        calculateButton.setPreferredSize(new Dimension(150, 40));
        calculateButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        calculateButton.addActionListener(e -> calculateGrade());
        
        resetButton = new JButton("Reset");
        resetButton.setFont(new Font("Arial", Font.BOLD, 14));
        resetButton.setBackground(new Color(243, 244, 246));
        resetButton.setForeground(new Color(55, 65, 81));
        resetButton.setFocusPainted(false);
        resetButton.setBorderPainted(false);
        resetButton.setPreferredSize(new Dimension(150, 40));
        resetButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        resetButton.addActionListener(e -> resetForm());
        
        panel.add(calculateButton);
        panel.add(resetButton);
        
        return panel;
    }
    
    private JPanel createResultPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(209, 213, 219), 1),
            "Results",
            0,
            0,
            new Font("Arial", Font.BOLD, 14),
            new Color(55, 65, 81)
        ));
        
        resultArea = new JTextArea();
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        resultArea.setEditable(false);
        resultArea.setBackground(new Color(249, 250, 251));
        resultArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JScrollPane scrollPane = new JScrollPane(resultArea);
        scrollPane.setPreferredSize(new Dimension(540, 250));
        
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private void calculateGrade() {
        try {
            // Get and validate inputs
            int attendance = Integer.parseInt(attendanceField.getText().trim());
            double lab1 = Double.parseDouble(lab1Field.getText().trim());
            double lab2 = Double.parseDouble(lab2Field.getText().trim());
            double lab3 = Double.parseDouble(lab3Field.getText().trim());
            
            // Validate ranges
            if (attendance < 0 || attendance > TOTAL_CLASSES) {
                showError("Attendance must be between 0 and " + TOTAL_CLASSES);
                return;
            }
            
            if (lab1 < 0 || lab1 > 100 || lab2 < 0 || lab2 > 100 || lab3 < 0 || lab3 > 100) {
                showError("Lab grades must be between 0 and 100");
                return;
            }
            
            // Calculate attendance score
            double attendanceScore = (double) attendance / TOTAL_CLASSES * 100;
            
            // Calculate Lab Work Average
            double labWorkAverage = (lab1 + lab2 + lab3) / 3.0;
            
            // Calculate Class Standing
            double classStanding = (attendanceScore * ATTENDANCE_WEIGHT) + 
                                  (labWorkAverage * LAB_WORK_WEIGHT);
            
            // Calculate required Prelim Exam scores
            double requiredForPassing = computeRequiredPrelimScore(classStanding, PASSING_GRADE);
            double requiredForExcellent = computeRequiredPrelimScore(classStanding, EXCELLENT_GRADE);
            
            // Display results
            displayResults(attendance, attendanceScore, lab1, lab2, lab3, 
                          labWorkAverage, classStanding, 
                          requiredForPassing, requiredForExcellent);
            
        } catch (NumberFormatException ex) {
            showError("Please enter valid numbers in all fields");
        }
    }
    
    private double computeRequiredPrelimScore(double classStanding, double targetGrade) {
        return (targetGrade - (classStanding * CLASS_STANDING_WEIGHT)) / PRELIM_EXAM_WEIGHT;
    }
    
    private void displayResults(int attendance, double attendanceScore,
                               double lab1, double lab2, double lab3,
                               double labWorkAverage, double classStanding,
                               double requiredForPassing, double requiredForExcellent) {
        StringBuilder result = new StringBuilder();
        
        result.append("═══════════════════════════════════════════════════════════\n");
        result.append("                         RESULTS\n");
        result.append("═══════════════════════════════════════════════════════════\n\n");
        
        result.append("INPUT SUMMARY\n");
        result.append("───────────────────────────────────────────────────────────\n");
        result.append(String.format("  Attendances:       %d / %d (%.2f%%)%n", 
                                   attendance, TOTAL_CLASSES, attendanceScore));
        result.append(String.format("  Lab Work 1:        %.2f%n", lab1));
        result.append(String.format("  Lab Work 2:        %.2f%n", lab2));
        result.append(String.format("  Lab Work 3:        %.2f%n", lab3));
        
        result.append("\nCOMPUTED VALUES\n");
        result.append("───────────────────────────────────────────────────────────\n");
        result.append(String.format("  Lab Work Average:  %.2f%n", labWorkAverage));
        result.append(String.format("  Class Standing:    %.2f%n", classStanding));
        
        result.append("\nREQUIRED PRELIM EXAM SCORES\n");
        result.append("───────────────────────────────────────────────────────────\n");
        result.append(String.format("  To Pass (75):      %.2f%n", requiredForPassing));
        result.append(String.format("  For Excellent:     %.2f%n", requiredForExcellent));
        
        result.append("\nREMARKS\n");
        result.append("───────────────────────────────────────────────────────────\n");
        
        // Passing grade remarks
        if (requiredForPassing > 100) {
            result.append("  Unfortunately, it is IMPOSSIBLE to pass.\n");
            result.append(String.format("  You would need %.2f in the Prelim Exam (exceeds 100).%n", 
                                       requiredForPassing));
            result.append("  Improve your attendance and lab work scores.\n");
        } else if (requiredForPassing < 0) {
            result.append("  You have already PASSED the Prelim period!\n");
            result.append("  Even with 0 on the exam, you will pass.\n");
        } else {
            result.append(String.format("  You need %.2f or higher in the Prelim Exam to PASS.%n", 
                                       requiredForPassing));
        }
        
        result.append("\n");
        
        // Excellent grade remarks
        if (requiredForExcellent > 100) {
            result.append("  Excellent grade (100) is not achievable.\n");
            result.append(String.format("  You would need %.2f in the Prelim Exam (exceeds 100).%n", 
                                       requiredForExcellent));
        } else if (requiredForExcellent < 0) {
            result.append("  You have already achieved EXCELLENT standing!\n");
        } else {
            result.append(String.format("  You need %.2f in the Prelim Exam for EXCELLENT standing.%n", 
                                       requiredForExcellent));
        }
        
        result.append("═══════════════════════════════════════════════════════════\n");
        
        resultArea.setText(result.toString());
        resultArea.setCaretPosition(0);
    }
    
    private void resetForm() {
        attendanceField.setText("");
        lab1Field.setText("");
        lab2Field.setText("");
        lab3Field.setText("");
        resultArea.setText("");
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Input Error", JOptionPane.ERROR_MESSAGE);
    }
    
    public static void main(String[] args) {
        // Set look and feel to system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Create and show GUI on Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            PrelimGradeCalculatorGUI frame = new PrelimGradeCalculatorGUI();
            frame.setVisible(true);
        });
    }
}
